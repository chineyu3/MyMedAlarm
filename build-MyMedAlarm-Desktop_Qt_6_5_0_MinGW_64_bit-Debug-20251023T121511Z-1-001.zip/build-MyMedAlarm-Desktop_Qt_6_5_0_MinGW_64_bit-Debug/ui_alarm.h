/********************************************************************************
** Form generated from reading UI file 'alarm.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ALARM_H
#define UI_ALARM_H

#include <QtCore/QVariant>
#include <QtWidgets/QAbstractButton>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCalendarWidget>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QTimeEdit>

QT_BEGIN_NAMESPACE

class Ui_Alarm
{
public:
    QLabel *label;
    QCheckBox *chkCustom;
    QCheckBox *chkWed;
    QCheckBox *chkThurs;
    QCheckBox *chkBastard;
    QCheckBox *chkTues;
    QDialogButtonBox *listAlmBtn;
    QSlider *VolumeSlider;
    QLabel *label_2;
    QGroupBox *groupBox;
    QGridLayout *gridLayout_3;
    QLabel *Clock_2;
    QCheckBox *chkSun;
    QDateEdit *CustEdit;
    QCheckBox *chkSounds;
    QCheckBox *chkSat;
    QLabel *lblTime;
    QCheckBox *chkFri;
    QCalendarWidget *calendarWidget;
    QPushButton *TestBtn;
    QCheckBox *chkMon;
    QListWidget *listWidget;
    QLabel *txtSoundPath;
    QTimeEdit *timeEdit;

    void setupUi(QDialog *Alarm)
    {
        if (Alarm->objectName().isEmpty())
            Alarm->setObjectName("Alarm");
        Alarm->resize(1300, 700);
        label = new QLabel(Alarm);
        label->setObjectName("label");
        label->setGeometry(QRect(0, 0, 1300, 700));
        label->setPixmap(QPixmap(QString::fromUtf8(":/src/Bg2.png")));
        label->setScaledContents(true);
        chkCustom = new QCheckBox(Alarm);
        chkCustom->setObjectName("chkCustom");
        chkCustom->setGeometry(QRect(313, 387, 150, 26));
        chkWed = new QCheckBox(Alarm);
        chkWed->setObjectName("chkWed");
        chkWed->setGeometry(QRect(618, 284, 105, 26));
        chkThurs = new QCheckBox(Alarm);
        chkThurs->setObjectName("chkThurs");
        chkThurs->setGeometry(QRect(730, 284, 88, 26));
        chkBastard = new QCheckBox(Alarm);
        chkBastard->setObjectName("chkBastard");
        chkBastard->setGeometry(QRect(470, 422, 134, 26));
        chkBastard->setCursor(QCursor(Qt::PointingHandCursor));
        chkTues = new QCheckBox(Alarm);
        chkTues->setObjectName("chkTues");
        chkTues->setGeometry(QRect(470, 284, 134, 26));
        listAlmBtn = new QDialogButtonBox(Alarm);
        listAlmBtn->setObjectName("listAlmBtn");
        listAlmBtn->setGeometry(QRect(1021, 508, 80, 101));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(listAlmBtn->sizePolicy().hasHeightForWidth());
        listAlmBtn->setSizePolicy(sizePolicy);
        listAlmBtn->setOrientation(Qt::Vertical);
        listAlmBtn->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ignore|QDialogButtonBox::Ok);
        VolumeSlider = new QSlider(Alarm);
        VolumeSlider->setObjectName("VolumeSlider");
        VolumeSlider->setGeometry(QRect(825, 426, 189, 18));
        VolumeSlider->setOrientation(Qt::Horizontal);
        label_2 = new QLabel(Alarm);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(825, 386, 189, 29));
        groupBox = new QGroupBox(Alarm);
        groupBox->setObjectName("groupBox");
        groupBox->setEnabled(true);
        groupBox->setGeometry(QRect(730, 82, 371, 195));
        groupBox->setAcceptDrops(false);
        groupBox->setAutoFillBackground(false);
        groupBox->setFlat(false);
        groupBox->setCheckable(false);
        gridLayout_3 = new QGridLayout(groupBox);
        gridLayout_3->setObjectName("gridLayout_3");
        Clock_2 = new QLabel(groupBox);
        Clock_2->setObjectName("Clock_2");
        Clock_2->setMinimumSize(QSize(0, 0));
        QFont font;
        font.setPointSize(26);
        Clock_2->setFont(font);
        Clock_2->setFrameShadow(QFrame::Sunken);
        Clock_2->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(Clock_2, 0, 0, 1, 1);

        chkSun = new QCheckBox(Alarm);
        chkSun->setObjectName("chkSun");
        chkSun->setGeometry(QRect(618, 317, 77, 26));
        CustEdit = new QDateEdit(Alarm);
        CustEdit->setObjectName("CustEdit");
        CustEdit->setGeometry(QRect(470, 386, 141, 29));
        chkSounds = new QCheckBox(Alarm);
        chkSounds->setObjectName("chkSounds");
        chkSounds->setGeometry(QRect(313, 422, 80, 26));
        chkSat = new QCheckBox(Alarm);
        chkSat->setObjectName("chkSat");
        chkSat->setGeometry(QRect(470, 317, 134, 26));
        lblTime = new QLabel(Alarm);
        lblTime->setObjectName("lblTime");
        lblTime->setGeometry(QRect(313, 350, 80, 29));
        chkFri = new QCheckBox(Alarm);
        chkFri->setObjectName("chkFri");
        chkFri->setGeometry(QRect(313, 317, 150, 26));
        calendarWidget = new QCalendarWidget(Alarm);
        calendarWidget->setObjectName("calendarWidget");
        calendarWidget->setGeometry(QRect(305, 80, 410, 195));
        TestBtn = new QPushButton(Alarm);
        TestBtn->setObjectName("TestBtn");
        TestBtn->setGeometry(QRect(825, 350, 189, 29));
        chkMon = new QCheckBox(Alarm);
        chkMon->setObjectName("chkMon");
        chkMon->setGeometry(QRect(313, 284, 150, 26));
        listWidget = new QListWidget(Alarm);
        listWidget->setObjectName("listWidget");
        listWidget->setGeometry(QRect(313, 482, 701, 153));
        txtSoundPath = new QLabel(Alarm);
        txtSoundPath->setObjectName("txtSoundPath");
        txtSoundPath->setGeometry(QRect(400, 455, 63, 20));
        timeEdit = new QTimeEdit(Alarm);
        timeEdit->setObjectName("timeEdit");
        timeEdit->setGeometry(QRect(470, 350, 141, 29));

        retranslateUi(Alarm);

        QMetaObject::connectSlotsByName(Alarm);
    } // setupUi

    void retranslateUi(QDialog *Alarm)
    {
        Alarm->setWindowTitle(QCoreApplication::translate("Alarm", "Dialog", nullptr));
        label->setText(QString());
        chkCustom->setText(QCoreApplication::translate("Alarm", "Custom Date:", nullptr));
        chkWed->setText(QCoreApplication::translate("Alarm", "Wednesday", nullptr));
        chkThurs->setText(QCoreApplication::translate("Alarm", "Thursday", nullptr));
#if QT_CONFIG(tooltip)
        chkBastard->setToolTip(QString());
#endif // QT_CONFIG(tooltip)
        chkBastard->setText(QCoreApplication::translate("Alarm", "Solve to Silence", nullptr));
        chkTues->setText(QCoreApplication::translate("Alarm", "Tuesday", nullptr));
        label_2->setText(QCoreApplication::translate("Alarm", "Master Volume:", nullptr));
        groupBox->setTitle(QCoreApplication::translate("Alarm", "Current Time:", nullptr));
        Clock_2->setText(QCoreApplication::translate("Alarm", "TextLabel", nullptr));
        chkSun->setText(QCoreApplication::translate("Alarm", "Sunday", nullptr));
        chkSounds->setText(QCoreApplication::translate("Alarm", "Use File", nullptr));
        chkSat->setText(QCoreApplication::translate("Alarm", "Saturday", nullptr));
        lblTime->setText(QCoreApplication::translate("Alarm", "Time:", nullptr));
        chkFri->setText(QCoreApplication::translate("Alarm", "Friday", nullptr));
        TestBtn->setText(QCoreApplication::translate("Alarm", "Test", nullptr));
        chkMon->setText(QCoreApplication::translate("Alarm", "Monday", nullptr));
        txtSoundPath->setText(QCoreApplication::translate("Alarm", "TextLabel", nullptr));
        timeEdit->setDisplayFormat(QCoreApplication::translate("Alarm", "hh:mm:ss:AP", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Alarm: public Ui_Alarm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ALARM_H
