/********************************************************************************
** Form generated from reading UI file 'account.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ACCOUNT_H
#define UI_ACCOUNT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Account
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *username;
    QLineEdit *password;
    QLabel *label_6;
    QLabel *label_7;
    QLineEdit *email;
    QLabel *label_8;
    QLineEdit *phone;
    QPushButton *pushButton;
    QLabel *label_9;
    QLabel *label_10;
    QPushButton *pushButton_2;
    QLabel *label_11;
    QLineEdit *passwordLogin;
    QLabel *label_12;
    QLineEdit *usrnameLogin;
    QLabel *label_13;
    QLabel *label_14;

    void setupUi(QDialog *Account)
    {
        if (Account->objectName().isEmpty())
            Account->setObjectName("Account");
        Account->resize(1300, 700);
        label = new QLabel(Account);
        label->setObjectName("label");
        label->setGeometry(QRect(0, 0, 1300, 700));
        label->setPixmap(QPixmap(QString::fromUtf8(":/src/Bg2.png")));
        label->setScaledContents(true);
        label_2 = new QLabel(Account);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(590, 10, 131, 121));
        label_2->setPixmap(QPixmap(QString::fromUtf8(":/src/Profile.png")));
        label_2->setScaledContents(true);
        label_3 = new QLabel(Account);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(0, 40, 1300, 700));
        label_3->setPixmap(QPixmap(QString::fromUtf8(":/src/White2.png")));
        label_3->setScaledContents(true);
        label_4 = new QLabel(Account);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(130, 160, 171, 31));
        QFont font;
        font.setFamilies({QString::fromUtf8("Montserrat SemiBold")});
        font.setPointSize(14);
        font.setBold(true);
        label_4->setFont(font);
        label_4->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 54)"));
        label_5 = new QLabel(Account);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(130, 200, 171, 31));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Montserrat Light")});
        font1.setPointSize(12);
        font1.setBold(false);
        label_5->setFont(font1);
        label_5->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 54)"));
        username = new QLineEdit(Account);
        username->setObjectName("username");
        username->setGeometry(QRect(130, 240, 381, 41));
        QFont font2;
        font2.setPointSize(13);
        username->setFont(font2);
        username->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	border: 2px solid rgb(255, 255, 255);\n"
"	border-radius: 20px;\n"
"	color: #FFF;\n"
"	padding-left: 20px;\n"
"	padding-right: 20px;\n"
"	background-color: rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 87);\n"
"}\n"
"color: black;"));
        password = new QLineEdit(Account);
        password->setObjectName("password");
        password->setGeometry(QRect(130, 330, 381, 41));
        password->setFont(font2);
        password->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	border: 2px solid rgb(255, 255, 255);\n"
"	border-radius: 20px;\n"
"	color: #FFF;\n"
"	padding-left: 20px;\n"
"	padding-right: 20px;\n"
"	background-color: rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 87);\n"
"}\n"
""));
        password->setEchoMode(QLineEdit::Password);
        label_6 = new QLabel(Account);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(130, 290, 171, 31));
        label_6->setFont(font1);
        label_6->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 54)"));
        label_7 = new QLabel(Account);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(130, 380, 171, 31));
        label_7->setFont(font1);
        label_7->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 54)"));
        email = new QLineEdit(Account);
        email->setObjectName("email");
        email->setGeometry(QRect(130, 420, 381, 41));
        email->setFont(font2);
        email->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	border: 2px solid rgb(255, 255, 255);\n"
"	border-radius: 20px;\n"
"	color: #FFF;\n"
"	padding-left: 20px;\n"
"	padding-right: 20px;\n"
"	background-color: rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 87);\n"
"}\n"
"color: black;"));
        label_8 = new QLabel(Account);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(130, 470, 171, 31));
        label_8->setFont(font1);
        label_8->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 54)"));
        phone = new QLineEdit(Account);
        phone->setObjectName("phone");
        phone->setGeometry(QRect(130, 510, 381, 41));
        QFont font3;
        font3.setPointSize(14);
        phone->setFont(font3);
        phone->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	border: 2px solid rgb(255, 255, 255);\n"
"	border-radius: 20px;\n"
"	color: #FFF;\n"
"	padding-left: 20px;\n"
"	padding-right: 20px;\n"
"	background-color: rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 87);\n"
"}\n"
"color: black;"));
        pushButton = new QPushButton(Account);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(210, 570, 201, 41));
        QFont font4;
        font4.setFamilies({QString::fromUtf8("Montserrat")});
        font4.setPointSize(12);
        font4.setBold(false);
        pushButton->setFont(font4);
        pushButton->setStyleSheet(QString::fromUtf8("border: 2px solid rgb(104, 147, 181);\n"
"border-radius: 20px;\n"
"color: #FFF;\n"
"padding-left: 20px;\n"
"padding-right: 20px;\n"
"background-color: rgb(104, 147, 181); "));
        label_9 = new QLabel(Account);
        label_9->setObjectName("label_9");
        label_9->setGeometry(QRect(220, 580, 201, 41));
        label_9->setPixmap(QPixmap(QString::fromUtf8(":/src/Sdw3.png")));
        label_9->setScaledContents(true);
        label_10 = new QLabel(Account);
        label_10->setObjectName("label_10");
        label_10->setGeometry(QRect(780, 330, 171, 31));
        label_10->setFont(font1);
        label_10->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 54)"));
        pushButton_2 = new QPushButton(Account);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(870, 440, 201, 41));
        pushButton_2->setFont(font4);
        pushButton_2->setStyleSheet(QString::fromUtf8("border: 2px solid rgb(104, 147, 181);\n"
"border-radius: 20px;\n"
"color: #FFF;\n"
"padding-left: 20px;\n"
"padding-right: 20px;\n"
"background-color: rgb(104, 147, 181); "));
        label_11 = new QLabel(Account);
        label_11->setObjectName("label_11");
        label_11->setGeometry(QRect(880, 450, 201, 41));
        label_11->setPixmap(QPixmap(QString::fromUtf8(":/src/Sdw3.png")));
        label_11->setScaledContents(true);
        passwordLogin = new QLineEdit(Account);
        passwordLogin->setObjectName("passwordLogin");
        passwordLogin->setGeometry(QRect(780, 370, 391, 41));
        passwordLogin->setFont(font3);
        passwordLogin->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	border: 2px solid rgb(255, 255, 255);\n"
"	border-radius: 20px;\n"
"	color: #FFF;\n"
"	padding-left: 20px;\n"
"	padding-right: 20px;\n"
"	background-color: rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 87);\n"
"}\n"
"color: black;"));
        passwordLogin->setEchoMode(QLineEdit::Password);
        label_12 = new QLabel(Account);
        label_12->setObjectName("label_12");
        label_12->setGeometry(QRect(780, 220, 171, 31));
        label_12->setFont(font1);
        label_12->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 54)"));
        usrnameLogin = new QLineEdit(Account);
        usrnameLogin->setObjectName("usrnameLogin");
        usrnameLogin->setGeometry(QRect(780, 260, 391, 41));
        usrnameLogin->setFont(font3);
        usrnameLogin->setStyleSheet(QString::fromUtf8("QLineEdit{\n"
"	border: 2px solid rgb(255, 255, 255);\n"
"	border-radius: 20px;\n"
"	color: #FFF;\n"
"	padding-left: 20px;\n"
"	padding-right: 20px;\n"
"	background-color: rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 87);\n"
"}\n"
"color: black;"));
        label_13 = new QLabel(Account);
        label_13->setObjectName("label_13");
        label_13->setGeometry(QRect(780, 160, 171, 31));
        label_13->setFont(font);
        label_13->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 54)"));
        label_14 = new QLabel(Account);
        label_14->setObjectName("label_14");
        label_14->setGeometry(QRect(-30, -80, 361, 351));
        label_14->setPixmap(QPixmap(QString::fromUtf8(":/src/Logo 3.png")));
        label_14->setScaledContents(true);
        label->raise();
        label_3->raise();
        label_11->raise();
        label_9->raise();
        label_2->raise();
        label_4->raise();
        label_5->raise();
        username->raise();
        password->raise();
        label_6->raise();
        label_7->raise();
        email->raise();
        label_8->raise();
        phone->raise();
        pushButton->raise();
        label_10->raise();
        pushButton_2->raise();
        passwordLogin->raise();
        label_12->raise();
        usrnameLogin->raise();
        label_13->raise();
        label_14->raise();

        retranslateUi(Account);

        QMetaObject::connectSlotsByName(Account);
    } // setupUi

    void retranslateUi(QDialog *Account)
    {
        Account->setWindowTitle(QCoreApplication::translate("Account", "Dialog", nullptr));
        label->setText(QString());
        label_2->setText(QString());
        label_3->setText(QString());
        label_4->setText(QCoreApplication::translate("Account", "Register Here", nullptr));
        label_5->setText(QCoreApplication::translate("Account", "Username", nullptr));
        username->setPlaceholderText(QCoreApplication::translate("Account", "Enter your username", nullptr));
        password->setPlaceholderText(QCoreApplication::translate("Account", "Enter your password", nullptr));
        label_6->setText(QCoreApplication::translate("Account", "Password", nullptr));
        label_7->setText(QCoreApplication::translate("Account", "Email", nullptr));
        email->setPlaceholderText(QCoreApplication::translate("Account", "Enter your email", nullptr));
        label_8->setText(QCoreApplication::translate("Account", "Phone", nullptr));
        phone->setPlaceholderText(QCoreApplication::translate("Account", "Enter your mobile number", nullptr));
        pushButton->setText(QCoreApplication::translate("Account", "Register", nullptr));
        label_9->setText(QString());
        label_10->setText(QCoreApplication::translate("Account", "Password", nullptr));
        pushButton_2->setText(QCoreApplication::translate("Account", "Log In", nullptr));
        label_11->setText(QString());
        passwordLogin->setPlaceholderText(QCoreApplication::translate("Account", "Enter password", nullptr));
        label_12->setText(QCoreApplication::translate("Account", "Username", nullptr));
        usrnameLogin->setPlaceholderText(QCoreApplication::translate("Account", "Enter username", nullptr));
        label_13->setText(QCoreApplication::translate("Account", "Log In Here", nullptr));
        label_14->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class Account: public Ui_Account {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ACCOUNT_H
