#include "account.h"
#include "ui_account.h"
#include "alarm.h"

Account::Account(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Account)
{
    ui->setupUi(this);
}

Account::~Account()
{
    delete ui;
}

void Account::on_pushButton_clicked()
{
    // Connecting To QSQLITE Database
    QSqlDatabase sqlitedb = QSqlDatabase::addDatabase("QSQLITE");

    sqlitedb.setDatabaseName("C:/Users/HUAWEI/Desktop/db/qt5register.sqlite");

    if(sqlitedb.open()){
        // Retrived Data From Input Fields

        QString username=ui->username->text();
        QString password=ui->password->text();
        QString email=ui->email->text();
        QString phone=ui->phone->text();

        //Run Our Insert Query
        QSqlQuery qry;

        qry.prepare("INSERT INTO users (username, password, email, phone)"
                    "VALUES (:username, :password, :email, :phone)");

        qry.bindValue(":username", username);
        qry.bindValue(":password", password);
        qry.bindValue(":email", email);
        qry.bindValue(":phone", phone);

        if(qry.exec()){

            QMessageBox::information(this, "Inserted","Data Inserted Successfully");
        }  else{
            QMessageBox::information(this, "Not Inserted","Data Is Not Connected");
        }


    }else{
        QMessageBox::information(this, "Not Connected","Database Is Not Connected");
    }
}


void Account::on_pushButton_2_clicked()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE", "MyConnect");
    db.setDatabaseName("C:/Users/HUAWEI/Desktop/db/qt5register.sqlite");

    QString username = ui->usrnameLogin->text();
    QString password = ui->passwordLogin->text();

    if (db.open()) {
        QSqlQuery query(QSqlDatabase::database("MyConnect"));
        query.prepare("SELECT * FROM users WHERE username=:username AND password=:password");
        query.bindValue(":username", username);
        query.bindValue(":password", password);

        if (query.exec()) {
            if (query.next()) {
                QMessageBox::information(this, "Success", "Login Success");
            //    Alarm alarm;
            //    alarm.setModal(true);
            //    alarm.exec();
                hide();
                alarm = new Alarm(this);
                alarm->show();

            } else {
                QMessageBox::information(this, "Failed", "Login Failed");
            }
        } else {
            QMessageBox::information(this, "Failed", "Query Failed To Execute");
        }
    } else {
        QMessageBox::information(this, "Database Failed", "Database Connection Failed");
    }
}

